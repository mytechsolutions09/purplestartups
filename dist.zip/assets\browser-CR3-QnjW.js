import{g as o}from"./index-DiRsppTU.js";var r,e;function t(){return e||(e=1,r=function(){throw new Error("ws does not work in the browser. Browser clients must use the native WebSocket object")}),r}var s=t();const n=o(s),w=Object.freeze(Object.defineProperty({__proto__:null,default:n},Symbol.toStringTag,{value:"Module"}));export{w as b};
//# sourceMappingURL=browser-CR3-QnjW.js.map
